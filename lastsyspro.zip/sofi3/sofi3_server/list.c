#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "list.h"
#include "serverfunc.h"

/*we use insert at start to insert the walletID with current_balance=length(list)*bitCoin value*/
void insert_at_start(Listptr *ptraddr, uint32_t v, uint32_t p)
/* Insert v as first element of list *ptraddr */ {
    Listptr templist;
    templist = *ptraddr; /* Save current start of list */
    *ptraddr = malloc(sizeof (struct listnode)); /* Space for new node */
    (*ptraddr)->ip=v; /* Put value */
    (*ptraddr)->port = p;
    (*ptraddr)->next = templist; /* Next element is former first */
}

int found(Listptr list, uint32_t v, uint32_t p) /* Check if v is member of list */ {
    while (list != NULL) /* Visit list elements up to the end */
        if ((list->ip==v)&&(list->port == p)) /* Did we find what we are looking for? */
            return 1; /* Yes, we did */
        else
            list = list->next; /* No, go to next element */
    return 0;
}

/*function to insert a node at the end*/

/*this function and insert_at_start is taken from introduction to programming*/
void insert_at_end(Listptr *ptraddr, uint32_t v, uint32_t p)
/* Insert v as last element of list *ptraddr */ {
    if (found(*ptraddr, v, p) == 0) {
        while (*ptraddr != NULL) /* Go to end of list */
            ptraddr = &((*ptraddr)->next); /* Prepare what we need to change */
        *ptraddr = malloc(sizeof (struct listnode)); /* Space for new node */
        (*ptraddr)->ip = v;
        (*ptraddr)->port = p;
        (*ptraddr)->next = NULL; /* There is no next element */

    }
}

int delete(Listptr *ptraddr,  uint32_t v, uint32_t p)
/* Delete element v from list *ptraddr, if it exists */ {
    Listptr templist;
    while ((*ptraddr) != NULL) /* Visit list elements up to the end */
        if (((*ptraddr)->ip==v)&&((*ptraddr)->port == p)) { /* Did we find what to delete? */
            templist = *ptraddr; /* Yes, save address of its node */
            *ptraddr = (*ptraddr)->next; /* Bypass deleted element */
            free(templist); /* Free memory for the corresponding node */
            return 1; /* We deleted the element */
        } else
            ptraddr = &((*ptraddr)->next); /* Prepare what we might change */
    return 0; /* We did't find the element we were looking for */
}

void print(Listptr list) /* Print elements of list */ {
    while (list != NULL) { /* Visit list elements up to the end */
        printf("|%s , %d|-->", make_IP_string(list->ip), list->port); /* Print current element */
        list = list->next; /* Go to next element */
    }
    printf("NULL\n"); /* Print end of list */
}

/*function to destroy list*/
void destroy_list(Listptr *head) {
    if ((*head)->next != NULL) {
        destroy_list(&((*head)->next));
    }
    free(*head);
    *head = NULL;
}



/*function to count list's length*/
int count_length(Listptr alist){
    int nodes=0;
    while(alist!=NULL){
        nodes++;
        alist=alist->next;
    }
    return nodes;
}

/*int main(void){
    Listptr alist;
    alist=NULL;
    insert_at_end(&alist,"132.05.06.70",9002);
    print(alist);
    insert_at_end(&alist,"132.05.06.70",9002);
    print(alist);
    //delete(&alist,"132.05.06.70",9002);
    //print(alist);
    destroy_list(&alist);
}*/