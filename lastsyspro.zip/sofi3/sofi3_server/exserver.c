
#include <stdio.h>
#include <sys/wait.h>      
#include <sys/types.h>     
#include <sys/socket.h>     
#include <netinet/in.h>     
#include <arpa/inet.h> 
#include <netdb.h>        
#include <unistd.h>         
#include <stdlib.h>                 
#include <signal.h> 
#include <string.h>
#include "list.h"
#include "serverfunc.h"


void signalhandler(int signo);
void handlefun(int newsock, Listptr* clientlist, fd_set* set);
Listptr clientlist;

int sock;

int main(int argc, char** argv) {

    clientlist = NULL; //server keeps client list
    int portNum, sock, newsock, maxsock, ret;
    unsigned int s;
    fd_set socks, readsocks;
    struct sockaddr_in server, client;
    struct sockaddr *serverptr = (struct sockaddr *) &server;
    socklen_t clientlen;
    struct sockaddr *clientptr = (struct sockaddr *) &client;

    if (argc != 3) { /*if the user hasn't given 2 arguments then exit*/
        printf("You didn't give portnum argument!\n");
        exit(-1);
    }

    portNum = atoi(argv[2]);
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1)
        perror_exit("Failed to create socket");

    server.sin_family = AF_INET; /* Internet domain */
    server.sin_addr.s_addr = htonl(INADDR_ANY);
    server.sin_port = htons(portNum); /* The given port */

    /* Bind socket to address */
    if (bind(sock, serverptr, sizeof (server)) < 0)
        perror_exit("bind");

    /* Listen for connections */
    if (listen(sock, 5) < 0) perror_exit("listen");
    printf("Listening for connections to port %d\n", portNum);

    signal(SIGINT, signalhandler);

    /* Set up the fd_set */
    FD_ZERO(&socks);
    FD_SET(sock, &socks);
    maxsock = sock;
    //------------select loop
    while (1) {
        readsocks = socks;
        clientlen = sizeof (client);
        //calling select
        ret = select(maxsock + 1, &readsocks, NULL, NULL, NULL);
        if (ret == -1) {
            perror("select");
            return 1;
        }
        for (s = 0; s <= maxsock; s++) {
            if (FD_ISSET(s, &readsocks)) {

                if (s == sock) { //something new into the mastersocket
                    if ((newsock = accept(sock, clientptr, &clientlen)) < 0) perror_exit("accept");

                    printf("Accepted connection\n");
                    FD_SET(newsock, &socks);
                    if (newsock > maxsock) {
                        maxsock = newsock;
                    }

                } else {
                    /* Handle read or disconnection */
                    handlefun(s, &clientlist, &socks);
                    FD_CLR(s, &socks);
                }
            }
        }
    }
    close(sock);

}

/*this function is called when a server receives a request in his master socket*/

void handlefun(int newsock, Listptr* clientlist, fd_set *set) {
    char commandbuf[20];
    read(newsock, commandbuf, sizeof (commandbuf));

    if (strcmp(commandbuf, "GET_CLIENTS") == 0)//server reads "GET_CLIENTS" from the new client
        send_client_list(newsock, clientlist);



    if (strcmp(commandbuf, "LOG_ON") == 0) //server reads "LOG_ON" from the new client
        perform_LOGON_request(newsock, clientlist);


    if (strcmp(commandbuf, "LOG_OFF") == 0) //server reads "LOG_OFF" from the new client
        perform_LOGOFF_request(newsock, clientlist);


    printf("Closing connection.\n");

    close(newsock); /* Close socket */
}

/*if server receives SIGINT it closes its master socket before exiting*/
void signalhandler(int signo) {
    printf("signal received: %d \n", signo);
    shutdown(sock, SHUT_RDWR);
    close(sock);
    exit(0);
}