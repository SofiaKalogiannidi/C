void perror_exit(char*);
uint32_t read_IP_from_socket(int );
uint32_t read_port_from_socket(int );
char* make_IP_string(uint32_t );
void write_IP_port_to_socket(int ,uint32_t   ,uint32_t  );
void send_message_to_all_clients(char* ,uint32_t ,uint32_t ,Listptr* );
void send_client_list(int ,Listptr* );
void perform_LOGON_request(int ,Listptr* );
void perform_LOGOFF_request(int ,Listptr* );


