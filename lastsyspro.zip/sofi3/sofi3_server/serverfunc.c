#include <stdio.h>
#include <sys/wait.h>      
#include <sys/types.h>     
#include <sys/socket.h>     
#include <netinet/in.h>     
#include <arpa/inet.h> 
#include <netdb.h>        
#include <unistd.h>         
#include <stdlib.h>                 
#include <signal.h> 
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>
#include <string.h>
#include "list.h"

void perror_exit(char* message) {
    perror(message);
    exit(EXIT_FAILURE);
}

/*this function reads the IP from a given socket and returns it*/
uint32_t read_IP_from_socket(int socket) {
    uint32_t network_ip;

    read(socket, &network_ip, sizeof (network_ip)); //read Ip from given socket
    uint32_t clip = ntohl(network_ip); //make from network to host  

    return clip;


}

/*this function reads the port from a given socket and returns it*/
uint32_t read_port_from_socket(int socket) {
    uint32_t network_port;
    read(socket, &network_port, sizeof (network_port));
    uint32_t clport = ntohl(network_port);
    return clport;

}

char* make_IP_string(uint32_t clip) {
    struct in_addr addr;
    addr.s_addr = clip;

    char * IPbuffer = inet_ntoa(addr); //use inet_ntoa to make it a string and
    return IPbuffer; //return the string
}

void write_IP_port_to_socket(int sock, uint32_t my_network_ip, uint32_t my_network_port) {
    if (write(sock, &my_network_ip, sizeof (my_network_ip)) < 0)
        perror_exit("write");



    if (write(sock, &my_network_port, sizeof (my_network_port)) < 0)
        perror_exit("write");
}

/*this function does these steps:
 * 1 connect every client in server's clientlist
 * 2 sends the message we want to client for example USER ON
 * 3 sends IP port of new client
 * 4 disconnects*/
void send_message_to_all_clients(char* message, uint32_t clip, uint32_t clport, Listptr* clientlist) {
    Listptr templist;
    templist = *clientlist;
    char command[20] = {0};
    int sock1;
    while (templist != NULL) {
        char* clientip;
        clientip = make_IP_string(templist->ip);
        uint32_t clientport = templist->port;
        struct sockaddr_in cl;
        if ((sock1 = socket(PF_INET, SOCK_STREAM, 0)) < 0)
            perror_exit("socket");
        cl.sin_family = AF_INET; /* Internet domain */
        cl.sin_port = htons(clientport); /* Server port */
        if (inet_pton(AF_INET, clientip, &cl.sin_addr) <= 0) {
            printf("\n inet_pton error occured\n");

        }

        if (connect(sock1, (struct sockaddr *) &cl, sizeof (cl)) < 0)
            perror_exit("connect");
        strcpy(command, message);
        if (write(sock1, command, sizeof (command)) < 0)
            perror_exit("write");
        uint32_t network_ip = htonl(clip);
        if (write(sock1, &network_ip, sizeof (network_ip)) < 0)
            perror_exit("write");
        uint32_t network_port = htonl(clport);
        if (write(sock1, &network_port, sizeof (network_port)) < 0)
            perror_exit("write");
        templist = templist->next;
        close(sock1);
    }
}

/*This function is called when server receives a message "GET_CLIENTS"
 * It follows these steps
 *  
       1. count list size of nodes in clientlist
       2. send "CLIENT_LIST"
       3. send the length of client list with ntohl
       4. for each IP and PORT in LIST
       5. send IP
       6. send PORT  to the client who made the request*/
void send_client_list(int newsock, Listptr* clientlist) {
    printf("A client wants my clientlist\n");
    char message[20] = {0};
    strcpy(message, "CLIENT_LIST");
    int nodes = count_length(*clientlist);
    if (write(newsock, message, sizeof (message)) < 0)
        perror_exit("write");
    nodes = htonl(nodes);
    if (write(newsock, &nodes, sizeof (nodes)) < 0)
        perror_exit("write");

    Listptr templist = *clientlist;
    while (templist != NULL) {
        uint32_t peerPORT = htonl(templist->port);
        uint32_t peerIP = htonl(templist->ip);
        write_IP_port_to_socket(newsock, peerIP, peerPORT);
        templist = templist->next;

    }
}

/*This function is executed when a client sends
 * "LOG_ON" to server.The steps are:
 *1.call  send_message_to_all_clients that sends "USER_ON"
 * to all the other clients
 * 2.insert <IP,port> into clientlist
 * 3.Write "Hello new client" to the new client*/
void perform_LOGON_request(int newsock, Listptr* clientlist) {

    uint32_t clip = read_IP_from_socket(newsock);
    char* IPbuffer = make_IP_string(clip);
    uint32_t clport = read_port_from_socket(newsock);

    printf("Client  with IP:%s and port: %u sent me LOG ON \n ", IPbuffer, clport);
    send_message_to_all_clients("USER_ON", clip, clport, clientlist);
    insert_at_end(clientlist, clip, clport);
    printf("-------------\n");
    print(*clientlist);
    char message[] = "Hello new client!\n";
    if (write(newsock, message, sizeof (message)) < 0)
        perror_exit("write");
}

/*when a client sends LOG_OFF
 * 1.delete its IP and port from clientlist
 * 2.send USER_OFF to the other clients*/
void perform_LOGOFF_request(int newsock, Listptr* clientlist) {

    uint32_t clip = read_IP_from_socket(newsock);
    char* IPbuffer = make_IP_string(clip);
    uint32_t clport = read_port_from_socket(newsock);
    printf("Client with IP:%s and port: %u sent me LOG OFF  \n", IPbuffer, clport);
    delete(clientlist, clip, clport); //remove IP and port from list
    send_message_to_all_clients("USER_OFF", clip, clport, clientlist);
    printf("------------------My new list is now---------\n");
    print(*clientlist);
}





