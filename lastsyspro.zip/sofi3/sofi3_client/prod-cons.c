#include <stdio.h>   // from www.mario-konrad.ch
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

#include "prod-cons.h"

static pthread_mutex_t mtx;
static pthread_cond_t cond_nonempty;
static pthread_cond_t cond_nonfull;

void initialize_pool(pool_t * pool, int b) {
    pool->start = 0;
    pool->end = -1;
    pool->count = 0;
    pool->b = b;
    pool->data = malloc(sizeof (Element) * b);

    pthread_mutex_init(&mtx, 0);
    pthread_cond_init(&cond_nonempty, 0);
    pthread_cond_init(&cond_nonfull, 0);
    
    printf("pool initialized \n");
}

void destroy_pool(pool_t * pool) {
    pthread_cond_destroy(&cond_nonempty);
    pthread_cond_destroy(&cond_nonfull);
    pthread_mutex_destroy(&mtx);

    free(pool->data);
    
    printf("pool destroyed \n");
}

void place_to_pool(pool_t * pool, Element elem) {
    pthread_mutex_lock(&mtx);
    while (pool->count >= pool->b) {
        pthread_cond_wait(&cond_nonfull, &mtx);
    }
    pool->end = (pool->end + 1) % pool->b;
    pool->data[pool->end] = elem;
    pool->count++;
    
   // printf("pool produce: %d %d \n", elem.ip, elem.port);
    
    pthread_mutex_unlock(&mtx);
    
    pthread_cond_broadcast(&cond_nonempty);
}

Element obtain_from_pool(pool_t * pool) {
    Element elem = { 0 };
    
    pthread_mutex_lock(&mtx);
    while (pool->count <= 0) {
        pthread_cond_wait(&cond_nonempty, &mtx);
    }
    elem = pool->data[pool->start];
    pool->start = (pool->start + 1) % pool->b;
    pool->count--;
    
   // printf("pool consume: %d %d  \n", elem.ip, elem.port);
    
    pthread_mutex_unlock(&mtx);
    
    pthread_cond_broadcast(&cond_nonfull);
    
    return elem;
}