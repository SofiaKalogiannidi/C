
#include "prod-cons.h"


void perror_exit(char* );
uint32_t get_my_IP();
uint32_t read_IP_from_socket(int );
uint32_t read_port_from_socket(int );
char* make_IP_string(uint32_t );
void write_IP_port_to_socket(int ,uint32_t   ,uint32_t  );
void send_GET_FILELIST_to_client(uint32_t ,uint32_t,pool_t*);
void send_GET_FILE_to_client(uint32_t , uint32_t,char* ,char*,char* );
void send_LOGOFF_to_server(char* ,int ,uint32_t,uint32_t);
Elements get_clients_from_server(char* ,int ,Listptr*,uint32_t,uint32_t );
Element insert_new_client(int ,Listptr* );
void delete_disconnected_client(int ,Listptr* );
int is_file(const char* );
int count_files_ofdir(char* );
void send_file_list(int ,char* );
int file_exists(char* );
void send_file(int );
void read_file_list(int,uint32_t ,uint32_t,pool_t* );
void read_file(int ,char*,char*);
