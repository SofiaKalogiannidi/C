#include <stdio.h>
#include <sys/types.h>      /* sockets */
#include <sys/socket.h>      /* sockets */
#include <netinet/in.h>      /* internet sockets */
#include <unistd.h>          /* read, write, close */
#include <netdb.h>          /* gethostbyaddr */
#include <stdlib.h>          /* exit */
#include <string.h>          /* strlen */
#include <arpa/inet.h> 
#include <getopt.h>
#include <signal.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/select.h>
#include "list.h"
#include "clientfunc.h"
#include "prod-cons.h"


char* dirname;
char* serverip;
char* myport;
uint32_t my_network_ip;
uint32_t my_network_port;
int port, threads, bsize, serverport;
void handlefun(int newsock, Listptr* clientlist, fd_set* set);
void signalhandler(int signo);
void* thread_function(void * params);
Listptr clientlist;
int master;
pool_t * pool = NULL;
pthread_t * workers = NULL;

int main(int argc, char *argv[]) {

    int c, ret, s, newsock, i;
    clientlist = NULL;
    char buf[1024] = { 0 }, recvBuff[1024]  = { 0 }, commandbuf[20] = { 0 };
    socklen_t clientlen;
    char *IPbuffer;
    while (1) {
        int option_index = 0;
        static struct option long_options[] = {
            {"d", required_argument, NULL, 'd'},
            {"p", required_argument, &port, 'r'},
            {"w", required_argument, &threads, 'w'},
            {"b", required_argument, &bsize, 'b'},
            {"sp", required_argument, &serverport, 'r'},
            {"sip", required_argument, NULL, 'x'},
        };

        c = getopt_long(argc, argv, "d:p:w:b:r:x",
                long_options, &option_index);

        if (c == -1)
            break;

        switch (c) {
            case 0:
                if (optarg)
                    serverport = atoi(optarg);
                break;
            case 'w':
                threads = atoi(optarg);
                break;
            case 'p':
                port = atoi(optarg);
                myport=optarg;
                break;
            case 'd':
                dirname = optarg;
                break;
            case 'b':
                bsize = atoi(optarg);
                break;
            case 'x':
                serverip = optarg;
                break;
            case '?':
                break;
            default:
                printf("?? getopt returned character code 0%d ??\n", c);
        }
    }
    mkdir(myport,0777);
    if (optind < argc) {
        printf("non-option ARGV-elements: ");
        while (optind < argc)
            printf("%s ", argv[optind++]);
        printf("\n");
    }

    struct sockaddr_in server;
    struct sockaddr *serverptr = (struct sockaddr*) &server;
    memset(&server, '0', sizeof (server));
    
    
    if ((master = socket(PF_INET, SOCK_STREAM, 0)) == -1)
        perror_exit("Failed to create socket");

    server.sin_family = AF_INET; /* Internet domain */
    server.sin_addr.s_addr = htonl(INADDR_ANY);
    server.sin_port = htons(port); /* The given port */

    /* Bind socket to address */
    if (bind(master, serverptr, sizeof (server)) < 0) {
        perror_exit("bind");
    }

    /* Listen for connections */
    if (listen(master, 25) < 0) {
        perror_exit("listen");
    }
    printf("Listening for connections to port %d\n", port);
    
    
    int sock;
    memset(recvBuff, '0', sizeof (recvBuff));
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        perror_exit("socket");

    memset(&server, '0', sizeof (server));
    server.sin_family = AF_INET; /* Internet domain */
    server.sin_port = htons(serverport); /* Server port */
    //-----------1st way they give IP
    if (inet_pton(AF_INET, serverip, &server.sin_addr) <= 0) {
        printf("\n inet_pton error occured\n");
        return 1;
    }
    //--------------2nd way they give the machine's name
     /*struct hostent *rem;
     if ((rem = gethostbyname(serverip)) == NULL) 	
	   herror("gethostbyname"); exit(1);
     memcpy(&server.sin_addr, rem->h_addr, rem->h_length);*/  
       
    uint32_t ip = get_my_IP();
    IPbuffer = make_IP_string(ip);

    my_network_ip = htonl(ip);
    my_network_port = htonl((uint32_t) port);


    /*LOG_ON*/
    printf("prepared message for server: LOG_ON %s %d\n", IPbuffer, port);
    strcpy(commandbuf, "LOG_ON");

    if (connect(sock, (struct sockaddr *) &server, sizeof (server)) < 0)
        perror_exit("connect");

    if (write(sock, commandbuf, sizeof (commandbuf)) < 0)
        perror_exit("write");

    write_IP_port_to_socket(sock, my_network_ip, my_network_port);
    bzero(buf, sizeof buf); /* Initialize buffer */

    if (read(sock, buf, sizeof buf) < 0) /* Receive message */
        perror_exit("read");

    printf("Read string:       %s\n", buf); /*Hello new client*/
    close(sock);

    
    // ***************************************************
    //             create producer consumer queue
    pool = malloc(sizeof (pool_t));

    initialize_pool(pool, bsize);


    // ***************************************************
    //             create worker threads
    workers = malloc(sizeof(pthread_t)*threads);
    
    for (i = 0; i < threads; i++) {
        pthread_create(&workers[i], NULL, thread_function, NULL);
    }

    /*GET CLIENTS*/

    signal(SIGINT, signalhandler);
    
    Elements elems = get_clients_from_server(serverip, serverport, &clientlist, my_network_ip, my_network_port);

    for (i=0;i<elems.size;i++) {
        place_to_pool(pool, elems.elementArray[i]);
    }
    
    free(elems.elementArray);

   

    /* Set up the fd_set */
    fd_set socks, readsocks;
    FD_ZERO(&socks);
    FD_SET(master, &socks);
    struct sockaddr_in client;
    struct sockaddr *clientptr = (struct sockaddr *) &client;
    int maxsock = master;
    while (1) {
        readsocks = socks;
        clientlen = sizeof (client);
        //calling select
        ret = select(maxsock + 1, &readsocks, NULL, NULL, NULL);
        if (ret == -1) {    
            perror("select");
            printf("master: %d \n",master);
            printf("max: %d \n",maxsock);
            return 1;
        }
        for (s = 0; s <= maxsock; s++) {
            if (FD_ISSET(s, &readsocks)) {
                if (s == master) { //something new into the mastersocket
                    if ((newsock = accept(master, clientptr, &clientlen)) < 0) {
                        perror_exit("accept");
                    }
                   
                    FD_SET(newsock, &socks);
                    if (newsock > maxsock) {
                        maxsock = newsock;
                    }
                } else {
                    /* Handle read or disconnection */
                    handlefun(s, &clientlist, &socks);
                    FD_CLR(s, &socks);
                }
            }
        }
    }
    close(master);


    destroy_pool(pool);
    free(pool);
}

void signalhandler(int signo) {
    int i;
    send_LOGOFF_to_server(serverip, serverport, my_network_ip, my_network_port);

    Element * elements = malloc(sizeof(Element)*threads);
    for (i=0;i<threads;i++) {
        elements[i].ip = 0;
        elements[i].port = 0;
        strcpy(elements[i].pathname,"Finishing");
        strcpy(elements[i].version,"end");
    }
    
    for (i=0;i<threads;i++) {
        place_to_pool(pool, elements[i]);
    }
    
    free(elements);
    
    for (i=0;i<threads;i++) {
        pthread_join(workers[i], 0);
    }
    
    close(master);

    destroy_pool(pool);
    free(pool);
    exit(0);
}

void handlefun(int newsock, Listptr* clientlist, fd_set *set) {
    char commandbuf[20]={0};

    read(newsock, commandbuf, sizeof (commandbuf));

    if (strcmp(commandbuf, "USER_ON") == 0) { //client reads "USER_ON" from server
        Element elem = insert_new_client(newsock, clientlist);
        place_to_pool(pool, elem);
    }

    if (strcmp(commandbuf, "USER_OFF") == 0) //client reads "USER_OFF" from server
        delete_disconnected_client(newsock, clientlist);

    if (strcmp(commandbuf, "GET_FILE_LIST") == 0) {
        send_file_list(newsock, dirname);
    }

    if (strcmp(commandbuf, "GET_FILE") == 0)
        send_file(newsock);
    
    printf("Closing connection.\n");

    close(newsock); /* Close socket */
}

void* thread_function(void * params) {
    pthread_t identifier = pthread_self();
            
    printf("HELLO from thread with identifier: %lu \n", identifier);
    
    while (1) {
        Element e = obtain_from_pool(pool);
        if (e.ip == 0) {
            break;
        }
        /*every thread sends "GET_FILE_LIST" to the object 
         * consumed from queue*/
         if(strcmp(e.version,"GET FILE LIST")==0)
            send_GET_FILELIST_to_client(e.ip, e.port,pool);
        
       else
           send_GET_FILE_to_client(e.ip, e.port,e.pathname,e.version,myport);
        
    }
    
    printf("BYE from thread with identifier: %lu \n", identifier);

    return 0;
}