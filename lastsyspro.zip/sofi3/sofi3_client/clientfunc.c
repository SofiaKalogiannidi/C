#include <stdio.h>
#include <sys/types.h>      /* sockets */
#include <sys/socket.h>      /* sockets */
#include <netinet/in.h>      /* internet sockets */
#include <unistd.h>          /* read, write, close */
#include <netdb.h>          /* gethostbyaddr */
#include <stdlib.h>          /* exit */
#include <string.h>          /* strlen */
#include <arpa/inet.h> 
#include <getopt.h>
#include <signal.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/file.h>
#include "list.h"
#include "clientfunc.h"
#include "prod-cons.h"

void perror_exit(char* message) {
    perror(message);
    exit(EXIT_FAILURE);
}

uint32_t get_my_IP() {
    struct hostent *host_entry;
    char hostbuffer[256];
    int hostname;
    /* To retrieve hostname*/
    hostname = gethostname(hostbuffer, sizeof (hostbuffer));
    if (hostname == -1) perror_exit("gethostname");
    /* To retrieve host information*/
    host_entry = gethostbyname(hostbuffer);
    if (host_entry == NULL) perror_exit("gethostbyname");
    /* To convert an Internet network address into ASCII string*/
    struct in_addr addr = *((struct in_addr*) host_entry->h_addr_list[0]);
    uint32_t ip = addr.s_addr;
    return ip;
}

/*this function reads the IP from a given socket and returns it*/
uint32_t read_IP_from_socket(int socket) {
    uint32_t network_ip;

    read(socket, &network_ip, sizeof (network_ip)); //read Ip from given socket
    uint32_t clip = ntohl(network_ip); //make from network to host  

    return clip;


}

/*this function reads the port from a given socket and returns it*/
uint32_t read_port_from_socket(int socket) {
    uint32_t network_port;
    read(socket, &network_port, sizeof (network_port));
    uint32_t clport = ntohl(network_port);
    return clport;

}

/*makes an IP printable string*/
char* make_IP_string(uint32_t clip) {
    struct in_addr addr;
    addr.s_addr = clip;

    char * IPbuffer = inet_ntoa(addr); //use inet_ntoa to make it a string and
    return IPbuffer; //return the string
}

void write_IP_port_to_socket(int sock, uint32_t my_network_ip, uint32_t my_network_port) {
    if (write(sock, &my_network_ip, sizeof (my_network_ip)) < 0)
        perror_exit("write");



    if (write(sock, &my_network_port, sizeof (my_network_port)) < 0)
        perror_exit("write");
}

/*---------------------------client-server communication-----------------------------------*/
/*LOG_OFF*/

/*connect to server sent him LOG_OFF IP PORT ,disconnect
 * and close socket
 * It is called from signalhandler when there is a 
 * signal SIGINT*/
void send_LOGOFF_to_server(char* serverip, int serverport, uint32_t my_network_ip,uint32_t my_network_port) {
    int sock1;
    char commandbuf[20]={0};
    struct sockaddr_in server;
    printf("I will send LOG OFF to server now\n");
    if ((sock1 = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        perror_exit("socket");

    server.sin_family = AF_INET; /* Internet domain */
    server.sin_port = htons(serverport); /* Server port */

    if (inet_pton(AF_INET, serverip, &server.sin_addr) <= 0)
        printf("\n inet_pton error occured\n");

    strcpy(commandbuf, "LOG_OFF");

    if (connect(sock1, (struct sockaddr *) &server, sizeof (server)) < 0)
        perror_exit("connect");

    if (write(sock1, commandbuf, sizeof (commandbuf)) < 0)
        perror_exit("write");

    write_IP_port_to_socket(sock1, my_network_ip, my_network_port);
    close(sock1);
}



/*This function follows these steps
 *    1. connect to server
     2. send GET_CLIENTS
     3. read "CLIENT_LIST"
     4. read list size
     5. for loop .... list size times
     5a. read IP
     5b. read PORT
     6.If the port and IP are not the same with the client's IP and port
     7. add to list
    8. disconnect*/
Elements get_clients_from_server(char* serverip, int serverport, Listptr* clientlist, uint32_t IP, uint32_t PORT) {
    int sock, i, j = 0;
    char commandbuf[20]={0};
    char response[20]={0};
    strcpy(commandbuf, "GET_CLIENTS");

    struct sockaddr_in server;
    server.sin_family = AF_INET; /* Internet domain */
    server.sin_port = htons(serverport); /* Server port */
    if (inet_pton(AF_INET, serverip, &server.sin_addr) <= 0)
        printf("\n inet_pton error occured\n");

    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        perror_exit("socket");

    if (connect(sock, (struct sockaddr *) &server, sizeof (server)) < 0)
        perror_exit("connect");

    if (write(sock, commandbuf, sizeof (commandbuf)) < 0)
        perror_exit("write");

    if (read(sock, response, sizeof response) < 0) { /* Receive message */
        perror("read");
        exit(1);
    }

    if (strcmp(response, "CLIENT_LIST") == 0) {
        int nodes;
        if (read(sock, &nodes, sizeof (nodes)) < 0) {
            exit(1);
        }
        nodes = ntohl(nodes);

        Elements elements;

        elements.size = nodes - 1;
        elements.elementArray = malloc(sizeof (Element) * elements.size);


        for (i = 0; i < nodes; i++) {
            uint32_t iptaken = read_IP_from_socket(sock);
            uint32_t porttaken = read_port_from_socket(sock);
            if (iptaken != ntohl(IP) || porttaken != ntohl(PORT)) {
                insert_at_end(clientlist, iptaken, porttaken);
                elements.elementArray[j].ip = iptaken;
                elements.elementArray[j].port = porttaken;
                strcpy(elements.elementArray[j].version, "GET FILE LIST");
                strcpy(elements.elementArray[j].pathname, "");
                j++;
            }
        }
        printf("List received from server---------\n");
        print(*clientlist);

        close(sock);

        return elements;
    } else {
        Elements elems = {0};
        elems.size = 0;

        close(sock);

        return elems;
    }
}

/*This function is called when the client receives "USER_ON" from server
 * The steps are:
 * 1.read IP from socket
 * 2.read port from socket
 * 3.insert them into clientlist
 * 4.print the clientlist*/
Element insert_new_client(int newsock, Listptr* clientlist) {

    uint32_t ip = read_IP_from_socket(newsock);
    uint32_t port = read_port_from_socket(newsock);
    char* IP = make_IP_string(ip);
    printf("Server told me that there is a new user with IP %s and port %u\n", IP, port);
    insert_at_end(clientlist, ip, port); //insert port and IP into client list
    print(*clientlist);

    Element elem;

    elem.ip = ip;
    elem.port = port;
    strcpy(elem.version, "GET FILE LIST");
    strcpy(elem.pathname, "");

    return elem;
}

/*This function is called when the client receives "USER_OFF" from server
 * The steps are:
 * 1.read IP from socket
 * 2.read port from socket
 * 3.delete them from clientlist
 * 4.print the clientlist*/
void delete_disconnected_client(int newsock, Listptr* clientlist) {
    uint32_t network_ip = read_IP_from_socket(newsock);
    uint32_t network_port = read_port_from_socket(newsock);
    char* IP = make_IP_string(network_ip);
    printf("Server told me that there is a disconnected user with IP %s and port %u\n", IP, network_port);
    delete(clientlist, network_ip, network_port); //delete port and IP from client list
    printf("My new client list is now\n");
    print(*clientlist);
}




/*-------------------------------------client-workers communication--------------------------------*/
void send_GET_FILELIST_to_client(uint32_t otherclientip, uint32_t otherclientport,pool_t* pool) {
    int sock1;
    char commandbuf[20]={0};
    struct sockaddr_in server;
    printf("I will send GET FILE LIST to a client now: %d :%d \n", otherclientip, otherclientport);
    
    if ((sock1 = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        perror_exit("socket");

    server.sin_family = AF_INET; /* Internet domain */
    server.sin_port = htons(otherclientport); /* Server port */
    server.sin_addr.s_addr = otherclientip;

    strcpy(commandbuf, "GET_FILE_LIST");

    if (connect(sock1, (struct sockaddr *) &server, sizeof (server)) < 0) {
        perror("connect");
        return;
    }

    if (write(sock1, commandbuf, sizeof (commandbuf)) < 0) {
        perror("write");
        return;
    }

    /* thread reads & prints in screen the files received
    from the other client*/
  
   read_file_list(sock1, otherclientip,  otherclientport,pool);
    
    
    close(sock1);
}


void send_GET_FILE_to_client(uint32_t otherclientip, uint32_t otherclientport,char* epathname,char* eversion,char* myport) {
    int sock1;
    char commandbuf[20]={0};
    char pathname[128]={0};
    char version[50]={0};
    struct sockaddr_in server;
    printf("I will send GET FILE  to a client now: %d :%d \n", otherclientip, otherclientport);
    
    if ((sock1 = socket(PF_INET, SOCK_STREAM, 0)) < 0)
        perror_exit("socket");

    server.sin_family = AF_INET; /* Internet domain */
    server.sin_port = htons(otherclientport); /* Server port */
    server.sin_addr.s_addr = otherclientip;

    strcpy(commandbuf, "GET_FILE");
    strcpy(pathname, epathname);
    strcpy(version, eversion);
    if (connect(sock1, (struct sockaddr *) &server, sizeof (server)) < 0) {
        perror("connect");
        return;
    }

    if (write(sock1, commandbuf, sizeof (commandbuf)) < 0) {
        perror("write");
        return;
    }
    
     if (write(sock1, pathname, sizeof (pathname)) < 0) {
        perror("write");
        return;
    }
    if (write(sock1, version, sizeof (version)) < 0) {
        perror("write");
        return;
    }

    /* thread reads & prints in screen the files received
    from the other client*/
  
   read_file(sock1, pathname,myport);
    
    
    close(sock1);
}



/*function to check if path is a file*/

int is_file(const char* path) {
    struct stat buf;
    stat(path, &buf);
    return S_ISREG(buf.st_mode);
}

/*returns the number of files in a directory*/
int count_files_ofdir(char* name) {
    int files = 0;
    DIR *dp;
    struct dirent *dir;
    char *newname;

    if ((dp = opendir(name)) == NULL)
        perror("opendir");
    while ((dir = readdir(dp)) != NULL) {
        if (dir->d_ino == 0) continue;
        if ((strcmp(dir->d_name, ".") != 0)&&(strcmp(dir->d_name, "..") != 0)) {
            newname = (char *) malloc(strlen(name) +
                    strlen(dir->d_name) + 2);

            strcpy(newname, name);
            strcat(newname, "/");
            strcat(newname, dir->d_name);
            if (is_file(newname) == 1) files++;
            free(newname);
            newname = NULL;
        }

    }

    closedir(dp);
    return files;
}

/*this function is called when client reads "GET_FILE_LIST" & sends all the pathnames and versions of
 * a given directory through a socket*/
void send_file_list(int newsocket, char* name) {
    DIR *dp;
    struct dirent *dir;
    char command[20]={0};
    printf("GET FILE LIST received !!!! \n");
 
    /* send file list !!!*/
    
    int n = count_files_ofdir(name);
    
    strcpy(command, "FILE_LIST");
    if (write(newsocket, command, sizeof (command)) < 0) perror_exit("write"); //write "FILE_LIST
    n = htonl(n);
    if (write(newsocket, &n, sizeof (n)) < 0) perror_exit("write"); //write num of files
    if ((dp = opendir(name)) == NULL) {
        perror("opendir");
        return;
    }
    while ((dir = readdir(dp)) != NULL) {
        if (dir->d_ino == 0) continue;
        if ((strcmp(dir->d_name, ".") != 0)&&(strcmp(dir->d_name, "..") != 0)) {
            char pathname[128]={0};
            strcpy(pathname, name);
            strcat(pathname, "/");
            strcat(pathname, dir->d_name);
            if (is_file(pathname) == 1) {

                if (write(newsocket, pathname, sizeof (pathname)) < 0) perror_exit("write"); //write pathname
                struct stat attr;
                stat(pathname, &attr);
                char version[50]={0};
                strcpy(version, ctime(&attr.st_mtime));

                if (write(newsocket, version, sizeof (version)) < 0) perror_exit("write"); //write version
            }

        }

    }
    closedir(dp);
}

int file_exists(char* name) {
    return access(name, F_OK);
}

/*This function is called when client reads "GET_FILE"*/
void send_file(int newsocket) {
    char pathname[128], version[50],response[20];
    if (read(newsocket, pathname, sizeof (pathname)) < 0) perror_exit("read"); //read pathname
    if (read(newsocket, version, sizeof (version)) < 0) perror_exit("read"); //read version
    if (file_exists(pathname) == -1) { //there is not that file you asked for
        strcpy(response, "FILE_NOT_FOUND");
        if (write(newsocket, response, sizeof (response)) < 0) perror_exit("write");
    } else {
        struct stat attr;
        stat(pathname, &attr);
        int size = attr.st_size;
        char current_version[50]={0};
        strcpy(current_version, ctime(&attr.st_mtime));
        if (strcmp(version, current_version) == 0) { //the file hasn't changed
            strcpy(response, "FILE_UP_TO_DATE");
            if (write(newsocket, response, sizeof (response)) < 0) perror_exit("write");
        } else {
            strcpy(response, "FILE_SIZE"); //we have to write the file 
            /*write "FILE_SIZE",current_version,file's size*/
            if (write(newsocket, response, sizeof (response)) < 0) perror_exit("write");
            if (write(newsocket, current_version, sizeof (current_version)) < 0) perror_exit("write");
            size = ntohl(size);
            if (write(newsocket, &size, sizeof (size)) < 0) perror_exit("write");
            int file_des = open(pathname, O_RDONLY);
            int written_count = 0;
            int nread;
            char buff[250];
            while ((nread = read(file_des, buff, sizeof (buff))) > 0 && written_count + sizeof (buff) <= size) {
                write(newsocket, buff, nread);
                
                written_count += nread;

            }
            read(file_des, buff, size - written_count);
          
            write(newsocket, buff, size - written_count);
            close(file_des);
        }
    }

}

void read_file_list(int newsocket,uint32_t otherclientip, uint32_t otherclientport,pool_t *pool) {

    char command[20];
    int i, n;
    if (read(newsocket, command, sizeof (command)) < 0) perror_exit("read");
    if (strcmp(command, "FILE_LIST") == 0) {
        if (read(newsocket, &n, sizeof (n)) < 0) perror_exit("read"); //write num of files
        n = ntohl(n);
        // printf("%d\n",n);
        for (i = 0; i < n; i++) {
            char pathname[128];
            if (read(newsocket, pathname, sizeof (pathname)) < 0) perror_exit("read");
            char version[50];
            if (read(newsocket, version, sizeof (version)) < 0) perror_exit("read");
             printf("%s %s\n",pathname,version);
             Element el;
             el.ip= otherclientip;
             el.port=otherclientport;
             strcpy(el.version,"newfile");
             strcpy(el.pathname,pathname);
             place_to_pool(pool, el);
             
        }
    }

}

void read_file(int newsocket,char* pathname,char* myport){
    char response[20];
    char version[50];
    int size;
    char* token=strchr(pathname,'/');
    if (token!=NULL) token++;
    char* newname=malloc(strlen(myport)+strlen(pathname)+1);
    strcpy(newname,myport);
    strcat(newname,"/");
    strcat(newname,token);
   
    if (read(newsocket, response, sizeof (response)) < 0) perror_exit("write");
     if(strcmp(response, "FILE_SIZE")==0){ //we have to write the file 
          
           
            if (read(newsocket, version, sizeof (version)) < 0) perror_exit("read");
            if (read(newsocket, &size, sizeof (size)) < 0) perror_exit("read");
            size=htonl(size);
            creat(newname,0644);
            int file_des = open(newname, O_WRONLY|O_CREAT|O_APPEND);
            int written_count = 0;
            int nread;
            char buff[250];
            while ((nread = read(newsocket, buff, sizeof (buff))) > 0 && written_count + sizeof (buff) <= size) {
                write(file_des, buff, nread);
                written_count += nread;

            }
            read(newsocket, buff, size - written_count);
            write(file_des, buff, size - written_count);
            close(file_des);
            
     }
    free(newname);
    newname=NULL; 
}