#ifndef PROD_CONS_H
#define PROD_CONS_H

#include <stdint.h>


typedef struct Element {
    uint32_t ip;
    uint32_t port;
    char version[50];
    char pathname[128];
} Element;



typedef struct Elements {
    Element * elementArray;
    int size;
} Elements;

typedef struct {
    Element * data;
    int start;
    int end;
    int count;
    int b;

 
} pool_t;

void initialize_pool(pool_t * pool, int b);
void destroy_pool(pool_t * pool);

void place_to_pool(pool_t * pool, Element data);
Element obtain_from_pool(pool_t * pool);


#endif /* PROD_CONS_H */

