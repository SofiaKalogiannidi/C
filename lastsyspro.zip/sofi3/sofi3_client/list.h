typedef struct listnode *Listptr;

struct listnode {
    uint32_t ip;
    uint32_t port;
    Listptr next;
};


void insert_at_start(Listptr*, uint32_t, uint32_t);
int found(Listptr, uint32_t, uint32_t);
void insert_at_end(Listptr *, uint32_t, uint32_t);
int delete(Listptr *, uint32_t, uint32_t);
void print(Listptr);
void destroy_list(Listptr *);
int count_length(Listptr);
